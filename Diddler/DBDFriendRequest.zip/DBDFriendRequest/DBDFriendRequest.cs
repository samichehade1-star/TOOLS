using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using Fiddler;

static class Program
{
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new MainForm());
    }
}

// ═══════════════════════════════════════════════════════════════════
//  DATA
// ═══════════════════════════════════════════════════════════════════
record CapturedRequest
{
    public Dictionary<string, string> Headers { get; init; } = new();
    public JsonElement BodyJson  { get; init; }
    public string      Host      { get; init; } = "";
    public string      Path      { get; init; } = "";
}
enum LogLevel { Info, Ok, Err, Discovery }

// ═══════════════════════════════════════════════════════════════════
//  FIDDLERCORE ENGINE
//  Uses FiddlerCore NuGet — same engine as Fiddler itself.
//  No system proxy conflicts, no keep-alive issues, no interference.
// ═══════════════════════════════════════════════════════════════════
class CaptureEngine
{
    const string TARGET_HOST = "grdk.live.bhvrdbd.com";
    const string PATH_ADD    = "/api/v1/players/friends/add";
    const string PATH_REMOVE = "/api/v1/players/friends/remove";
    const int    PROXY_PORT  = 8877;

    public CapturedRequest? AddCapture    { get; private set; }
    public CapturedRequest? RemoveCapture { get; private set; }

    public event Action<string, LogLevel>? LogMessage;
    public event Action<CapturedRequest>?  OnAddCapture;
    public event Action<CapturedRequest>?  OnRemoveCapture;
    public event Action<string, string>?   OnUrlDiscovered;

    readonly HashSet<string> _seenPaths = new();

    public bool Start()
    {
        try
        {
            // Hook session events before starting
            FiddlerApplication.BeforeRequest        += OnBeforeRequest;
            FiddlerApplication.BeforeResponse       += OnBeforeResponse;
            FiddlerApplication.AfterSessionComplete += OnSessionComplete;

            // Install root cert if needed (same as Fiddler's "Trust Root Cert")
            if (!CertMaker.rootCertExists())
                CertMaker.createRootCert();
            if (!CertMaker.rootCertIsTrusted())
                CertMaker.trustRootCert();

            // Startup flags: act as system proxy + decrypt HTTPS
            var flags = FiddlerCoreStartupFlags.RegisterAsSystemProxy
                      | FiddlerCoreStartupFlags.DecryptSSL;

            FiddlerApplication.Startup(PROXY_PORT, flags);
            Log($"FiddlerCore proxy started on port {PROXY_PORT}", LogLevel.Ok);
            return true;
        }
        catch (Exception ex)
        {
            Log($"FiddlerCore start failed: {ex.Message}", LogLevel.Err);
            return false;
        }
    }

    public void Stop()
    {
        try
        {
            FiddlerApplication.BeforeRequest  -= OnBeforeRequest;
            FiddlerApplication.BeforeResponse -= OnBeforeResponse;
            FiddlerApplication.AfterSessionComplete -= OnSessionComplete;
            FiddlerApplication.Shutdown();
            Log("FiddlerCore stopped.", LogLevel.Info);
        }
        catch { }
    }

    void OnBeforeRequest(Session s)
    {
        // Only care about our target host
        if (!s.hostname.Equals(TARGET_HOST, StringComparison.OrdinalIgnoreCase)) return;

        var path = s.PathAndQuery;

        // Log every new URL we see from this host
        var key = $"{s.RequestMethod} {path}";
        lock (_seenPaths)
        {
            if (_seenPaths.Add(key))
            {
                Log($"[URL]  {s.RequestMethod}  {path}", LogLevel.Discovery);
                OnUrlDiscovered?.Invoke(s.RequestMethod, path);
            }
        }
    }

    void OnBeforeResponse(Session s)
    {
        if (!s.hostname.Equals(TARGET_HOST, StringComparison.OrdinalIgnoreCase)) return;

        var path = s.PathAndQuery;

        // Capture friend-add
        if (path.StartsWith(PATH_ADD, StringComparison.OrdinalIgnoreCase))
            TryCapture(s, isAdd: true);
        // Capture friend-remove
        else if (path.StartsWith(PATH_REMOVE, StringComparison.OrdinalIgnoreCase))
            TryCapture(s, isAdd: false);
    }

    void OnSessionComplete(Session s) { /* no-op — here for future use */ }

    void TryCapture(Session s, bool isAdd)
    {
        try
        {
            var body = s.GetRequestBodyAsString();
            var json = JsonDocument.Parse(body);

            // Build headers dict from FiddlerCore headers
            var hdrs = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (HTTPHeaderItem h in s.oRequest.headers)
                hdrs[h.Name] = h.Value;

            var cap = new CapturedRequest
            {
                Headers  = hdrs,
                BodyJson = json.RootElement.Clone(),
                Host     = s.hostname,
                Path     = s.PathAndQuery,
            };

            string fid = "";
            try { fid = cap.BodyJson.GetProperty("ids")[0].GetString() ?? ""; } catch { }

            if (isAdd)
            {
                AddCapture = cap;
                Log($"✓ ADD token captured  [{fid[..Math.Min(8, fid.Length)]}…]", LogLevel.Ok);
                OnAddCapture?.Invoke(cap);
            }
            else
            {
                RemoveCapture = cap;
                Log($"✓ REMOVE token captured  [{fid[..Math.Min(8, fid.Length)]}…]", LogLevel.Ok);
                OnRemoveCapture?.Invoke(cap);
            }
        }
        catch (Exception ex) { Log($"Capture parse error: {ex.Message}", LogLevel.Err); }
    }

    // ── send custom request using captured token ───────────────────
    public async Task<(bool ok, string status)> SendRequest(
        CapturedRequest cap, string path, string playerId)
    {
        try
        {
            var payload = JsonSerializer.SerializeToUtf8Bytes(
                new { ids = new[] { playerId }, platform = "kraken" });

            using var http = new HttpClient(new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (_, _, _, _) => true
            })
            { Timeout = TimeSpan.FromSeconds(15) };

            var skip = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                "content-length", "transfer-encoding", "connection",
                "host", "content-type", "proxy-connection"
            };

            var req = new HttpRequestMessage(HttpMethod.Post,
                $"https://{TARGET_HOST}{path}");
            req.Content = new ByteArrayContent(payload);
            req.Content.Headers.ContentType =
                new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");

            foreach (var kv in cap.Headers)
                if (!skip.Contains(kv.Key))
                    req.Headers.TryAddWithoutValidation(kv.Key, kv.Value);

            var resp  = await http.SendAsync(req);
            var rb    = await resp.Content.ReadAsStringAsync();
            return ((int)resp.StatusCode < 400,
                    $"{(int)resp.StatusCode} {resp.ReasonPhrase}  {rb[..Math.Min(300, rb.Length)]}");
        }
        catch (Exception ex) { return (false, ex.Message); }
    }

    void Log(string msg, LogLevel lvl) => LogMessage?.Invoke(msg, lvl);
}


// ═══════════════════════════════════════════════════════════════════
//  MAIN FORM  — Diddler UI
// ═══════════════════════════════════════════════════════════════════
class MainForm : Form
{
    // palette
    static readonly Color Bg       = Color.FromArgb(13,  13,  20);
    static readonly Color Card     = Color.FromArgb(22,  22,  36);
    static readonly Color CardBrd  = Color.FromArgb(46,  46,  68);
    static readonly Color Input    = Color.FromArgb(14,  14,  26);
    static readonly Color InputBrd = Color.FromArgb(40,  40,  64);
    static readonly Color Purple   = Color.FromArgb(155, 75,  255);
    static readonly Color PurpleBtn= Color.FromArgb(122, 56,  204);
    static readonly Color RedClr   = Color.FromArgb(215, 60,  60);
    static readonly Color RedBtn   = Color.FromArgb(168, 44,  44);
    static readonly Color Green    = Color.FromArgb(80,  200, 100);
    static readonly Color Orange   = Color.FromArgb(224, 120, 32);
    static readonly Color TextPri  = Color.FromArgb(220, 220, 232);
    static readonly Color TextMut  = Color.FromArgb(90,  90,  120);
    static readonly Color TextDim  = Color.FromArgb(46,  46,  68);
    static readonly Color Gold     = Color.FromArgb(255, 185, 45);
    static readonly Color TlRed    = Color.FromArgb(237, 95,  87);
    static readonly Color TlYellow = Color.FromArgb(242, 184, 80);
    static readonly Color TlGreen  = Color.FromArgb(98,  196, 98);
    static readonly Color LogBg    = Color.FromArgb(10,  10,  18);

    const string PATH_ADD    = "/api/v1/players/friends/add";
    const string PATH_REMOVE = "/api/v1/players/friends/remove";
    const int    TITLE_H     = 48;
    const int    BOT_H       = 42;
    const int    CARD_H      = 118;
    const int    PAD         = 14;
    const int    GAP         = 10;

    readonly CaptureEngine _engine = new();

    DoubleBufferedPanel? _titleBar, _addCard, _removeCard, _botBar;
    RichTextBox?         _log;
    Label?               _lblStatus, _addBadge, _removeBadge;
    Panel?               _dotStatus;
    TextBox?             _txtAdd,    _txtRemove;
    Button?              _btnAdd,    _btnRemove;

    public MainForm()
    {
        Text            = "Diddler";
        ClientSize      = new Size(820, 660);
        MinimumSize     = new Size(700, 540);
        BackColor       = Bg;
        ForeColor       = TextPri;
        Font            = new Font("Segoe UI", 10f);
        StartPosition   = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.None;
        AutoScaleMode   = AutoScaleMode.Dpi;

        // Set exe icon
        try
        {
            var ico = new System.Drawing.Icon(
                System.Reflection.Assembly.GetExecutingAssembly()
                    .GetManifestResourceStream("DBDFriendRequest.diddler.ico")!);
            Icon = ico;
        }
        catch { }

        Build();

        _engine.LogMessage      += (m, l) => TryInvoke(() => WriteLog(m, l));
        _engine.OnAddCapture    += c      => TryInvoke(() => GotAdd(c));
        _engine.OnRemoveCapture += c      => TryInvoke(() => GotRemove(c));

        MouseDown += WinDrag;
        Resize    += (s, e) => DoLayout();
        Task.Run(Boot);
    }

    void WinDrag(object? s, MouseEventArgs e)
    { if (e.Button == MouseButtons.Left) { ReleaseCapture(); SendMessage(Handle, 0xA1, 2, 0); } }

    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool ReleaseCapture();
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern int  SendMessage(IntPtr h, int msg, int wp, int lp);

    protected override void WndProc(ref Message m)
    {
        const int WM_NCHITTEST = 0x84;
        const int grip = 8;
        if (m.Msg == WM_NCHITTEST)
        {
            base.WndProc(ref m);
            var pt = PointToClient(new Point((int)(m.LParam.ToInt64() & 0xFFFF), (int)(m.LParam.ToInt64() >> 16)));
            bool l = pt.X < grip, r = pt.X > Width-grip, t = pt.Y < grip, b = pt.Y > Height-grip;
            if (t&&l){m.Result=(IntPtr)13;return;} if (t&&r){m.Result=(IntPtr)14;return;}
            if (b&&l){m.Result=(IntPtr)16;return;} if (b&&r){m.Result=(IntPtr)17;return;}
            if (l){m.Result=(IntPtr)10;return;} if (r){m.Result=(IntPtr)11;return;}
            if (t){m.Result=(IntPtr)12;return;} if (b){m.Result=(IntPtr)15;return;}
            return;
        }
        base.WndProc(ref m);
    }

    void Boot()
    {
        while (!IsHandleCreated) System.Threading.Thread.Sleep(50);
        SetSt("Starting...", Gold);
        if (!_engine.Start()) { SetSt("Failed to start", RedClr); return; }
        System.Threading.Thread.Sleep(300);
        SetSt("Ready — open DBD and trigger tokens once each", TextMut);
        WriteLog("Ready — trigger a friend-add and friend-remove in DBD to capture tokens", LogLevel.Info);
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    { _engine.Stop(); base.OnFormClosed(e); }

    // ── layout ────────────────────────────────────────────────
    void DoLayout()
    {
        if (_titleBar == null) return;
        int W = ClientSize.Width, H = ClientSize.Height;
        int cW = W - PAD * 2;

        _titleBar.SetBounds(0, 0, W, TITLE_H);
        _botBar!.SetBounds(0, H - BOT_H, W, BOT_H);

        int y = TITLE_H + PAD;
        _addCard!.SetBounds(PAD, y, cW, CARD_H);
        y += CARD_H + GAP;
        _removeCard!.SetBounds(PAD, y, cW, CARD_H);
        y += CARD_H + GAP;

        int logH = H - y - BOT_H - PAD;
        _log!.SetBounds(PAD, y, cW, Math.Max(logH, 40));

        ReflowCard(_addCard,    _txtAdd!,    _btnAdd!);
        ReflowCard(_removeCard, _txtRemove!, _btnRemove!);
        LayoutBot(W);
    }

    static void ReflowCard(Panel card, TextBox txt, Button btn)
    {
        int btnW = 152, btnL = card.Width - btnW - 12;
        btn.Left = btnL; btn.Width = btnW;
        if (txt.Parent is Panel wrap) { wrap.Width = btnL - 12 - 8; txt.Width = wrap.Width - 20; }
    }

    void LayoutBot(int W)
    {
        if (_lblStatus == null || _dotStatus == null) return;
        _lblStatus.Left = W - _lblStatus.Width - 18;
        _dotStatus.Left = _lblStatus.Left - 12;
    }

    // ── build ─────────────────────────────────────────────────
    void Build()
    {
        SuspendLayout();

        // title bar
        _titleBar = new DoubleBufferedPanel { BackColor = Color.FromArgb(11,11,18) };
        _titleBar.Paint    += (s, e) => e.Graphics.DrawLine(new Pen(Color.FromArgb(32,32,48)), 0, TITLE_H-1, _titleBar.Width, TITLE_H-1);
        _titleBar.MouseDown += WinDrag;

        // traffic lights
        var tl = new Panel { Width=62, Height=13, Top=18, Left=14, BackColor=Color.Transparent };
        tl.Paint += (s, e) => {
            var g=e.Graphics; g.SmoothingMode=SmoothingMode.AntiAlias;
            using(var b=new SolidBrush(TlRed))    g.FillEllipse(b, 0,0,12,12);
            using(var b=new SolidBrush(TlYellow)) g.FillEllipse(b,18,0,12,12);
            using(var b=new SolidBrush(TlGreen))  g.FillEllipse(b,36,0,12,12);
        };
        tl.Cursor=Cursors.Hand;
        tl.MouseClick += (s,e) => {
            if(e.X<=14) Close();
            else if(e.X<=33) WindowState=FormWindowState.Minimized;
            else WindowState=WindowState==FormWindowState.Maximized?FormWindowState.Normal:FormWindowState.Maximized;
        };
        _titleBar.Controls.Add(tl);

        // D logo in title
        var logoPanel = new Panel { Width=36, Height=36, Top=6, Left=82, BackColor=Color.Transparent };
        logoPanel.Paint += DrawDLogo;
        _titleBar.Controls.Add(logoPanel);

        _titleBar.Controls.Add(new Label { Text="DIDDLER", ForeColor=TextPri,
            Font=new Font("Arial Black", 12, FontStyle.Bold), AutoSize=true,
            Top=13, Left=124, BackColor=Color.Transparent, Tag="title" });

        var lblBy=new Label { Text="by Sami", ForeColor=Color.FromArgb(120,80,190),
            Font=new Font("Segoe UI",9,FontStyle.Italic), AutoSize=true,
            Top=15, BackColor=Color.Transparent };
        _titleBar.SizeChanged += (s,e) => lblBy.Left=_titleBar.Width-lblBy.Width-16;
        _titleBar.Controls.Add(lblBy);
        Controls.Add(_titleBar);

        // cards
        _addCard    = MakeCard("FRIEND ADD",                      Purple, Color.FromArgb(28,16,46), Color.FromArgb(60,36,100),
                               PurpleBtn, out _addBadge,    out _txtAdd,    out _btnAdd,    "+ SEND ADD",    () => _ = Go(true));
        _removeCard = MakeCard("FRIEND REMOVE / CANCEL REQUEST",  RedClr, Color.FromArgb(28,12,12), Color.FromArgb(72,28,28),
                               RedBtn,    out _removeBadge, out _txtRemove, out _btnRemove, "X SEND REMOVE", () => _ = Go(false));
        Controls.Add(_addCard);
        Controls.Add(_removeCard);

        // log
        _log = new RichTextBox { BackColor=LogBg, ForeColor=TextMut,
            Font=new Font("Consolas",9), BorderStyle=BorderStyle.None,
            ReadOnly=true, ScrollBars=RichTextBoxScrollBars.Vertical };
        Controls.Add(_log);

        // bottom bar
        _botBar = new DoubleBufferedPanel { BackColor=Color.FromArgb(11,11,18) };
        _botBar.Paint    += (s,e) => e.Graphics.DrawLine(new Pen(Color.FromArgb(32,32,48)), 0, 0, _botBar.Width, 0);
        _botBar.MouseDown += WinDrag;

        var botLogo=new Panel { Width=22, Height=22, Top=10, Left=14, BackColor=Color.Transparent };
        botLogo.Paint += (s,e) => DrawDLogoSmall(e.Graphics, 22);
        _botBar.Controls.Add(botLogo);

        _botBar.Controls.Add(new Label { Text="DIDDLER", ForeColor=Color.FromArgb(100,100,120),
            Font=new Font("Arial Black",7,FontStyle.Bold), AutoSize=true,
            Top=13, Left=40, BackColor=Color.Transparent });
        _botBar.Controls.Add(new Label { Text="by Sami", ForeColor=Color.FromArgb(120,70,180),
            Font=new Font("Segoe UI",7,FontStyle.Italic), AutoSize=true,
            Top=13, Left=110, BackColor=Color.Transparent });

        _dotStatus=new Panel { Width=7,Height=7, Top=18, BackColor=TextMut };
        Circle(_dotStatus);
        _lblStatus=new Label { Text="starting...", ForeColor=TextMut,
            Font=new Font("Segoe UI",8.5f), AutoSize=true, Top=14, BackColor=Color.Transparent };
        _botBar.SizeChanged += (s,e) => {
            _lblStatus.Left=_botBar.Width-_lblStatus.Width-16;
            _dotStatus.Left=_lblStatus.Left-11;
        };
        _botBar.Controls.Add(_dotStatus);
        _botBar.Controls.Add(_lblStatus);

        _botBar.Controls.Add(new Label {
            Text="Powered by FiddlerCore  -  No system proxy conflicts",
            ForeColor=TextDim, Font=new Font("Segoe UI",6.5f), AutoSize=true,
            Top=_botBar.Height, Left=14, BackColor=Color.Transparent });
        Controls.Add(_botBar);

        ResumeLayout();
        DoLayout();
    }

    static void DrawDLogo(object? s, PaintEventArgs e)
    { DrawDLogoAt(e.Graphics, ((Panel)s!).Width); }

    // Draws the double-D logo: large outer D + smaller inner D offset left, orange accent
    static void DrawDLogoAt(Graphics g, int size)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        float lw  = Math.Max(2f, size / 8f);
        float lw2 = Math.Max(1.5f, size / 11f);

        var silver = Color.FromArgb(210, 210, 218);
        var orange = Color.FromArgb(224, 115, 28);

        using var penSilver = new Pen(silver, lw)  { StartCap = System.Drawing.Drawing2D.LineCap.Square, EndCap = System.Drawing.Drawing2D.LineCap.Square };
        using var penInner  = new Pen(silver, lw2) { StartCap = System.Drawing.Drawing2D.LineCap.Square, EndCap = System.Drawing.Drawing2D.LineCap.Square };
        using var penOrange = new Pen(orange, lw2) { StartCap = System.Drawing.Drawing2D.LineCap.Round,  EndCap = System.Drawing.Drawing2D.LineCap.Round  };

        float pad = size * 0.08f;

        // ── Large outer D ────────────────────────────────────
        float ox = size * 0.38f, oy = pad;
        float ow = size - ox - pad, oh = size - pad * 2;
        // vertical left bar of outer D
        g.DrawLine(penSilver, ox, oy, ox, oy + oh);
        // top horizontal
        g.DrawLine(penSilver, ox, oy, ox + ow * 0.5f, oy);
        // bottom horizontal
        g.DrawLine(penSilver, ox, oy + oh, ox + ow * 0.5f, oy + oh);
        // right arc
        g.DrawArc(penSilver, ox, oy, ow, oh, -90, 180);

        // ── Small inner D (offset left, smaller) ─────────────
        float ix = size * 0.14f, iy = size * 0.20f;
        float iw = size * 0.46f, ih = size * 0.60f;
        // vertical bar
        g.DrawLine(penInner, ix, iy, ix, iy + ih);
        // top
        g.DrawLine(penInner, ix, iy, ix + iw * 0.4f, iy);
        // bottom
        g.DrawLine(penInner, ix, iy + ih, ix + iw * 0.4f, iy + ih);
        // right arc of inner D (grey portion)
        g.DrawArc(penInner, ix, iy, iw, ih, -90, 150);
        // orange accent on inner D right arc (bottom sweep)
        g.DrawArc(penOrange, ix, iy, iw, ih, 60, 30);
    }

    static void DrawDLogoSmall(Graphics g, int size)
    { DrawDLogoAt(g, size); }

    // ── card factory ─────────────────────────────────────────
    DoubleBufferedPanel MakeCard(string title, Color accent, Color badgeBg, Color badgeBrd,
        Color btnColor, out Label badge, out TextBox txt, out Button btn,
        string btnText, Action onSend)
    {
        var card = new DoubleBufferedPanel { BackColor=Card };
        card.Paint += (s,e) => {
            e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
            using var p=new Pen(CardBrd,1);
            using var gp=RRect(new Rectangle(0,0,card.Width-1,card.Height-1),10);
            e.Graphics.DrawPath(p,gp);
        };

        // dot + title
        var dot=new Panel { Width=7,Height=7, Top=14, Left=14, BackColor=accent };
        Circle(dot); card.Controls.Add(dot);
        card.Controls.Add(new Label { Text=title, ForeColor=accent,
            Font=new Font("Segoe UI",8,FontStyle.Bold), AutoSize=true,
            Top=11, Left=27, BackColor=Color.Transparent });

        // badge top-right
        var lb=new Label { Text="  Waiting for token...  ", ForeColor=Color.FromArgb(90,70,120),
            BackColor=badgeBg, Font=new Font("Segoe UI",7.5f),
            AutoSize=true, Top=8, Padding=new Padding(6,3,6,3) };
        lb.Paint += (s,e) => {
            e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
            using var gp=RRect(new Rectangle(0,0,lb.Width-1,lb.Height-1),5);
            using var pen=new Pen(badgeBrd,1); e.Graphics.DrawPath(pen,gp);
            using var br=new SolidBrush(badgeBg); e.Graphics.FillPath(br,gp);
        };
        badge=lb; card.Controls.Add(lb);
        card.Resize += (s,e) => lb.Left=card.Width-lb.Width-12;

        // input
        var wrap=new DoubleBufferedPanel { BackColor=Input, Top=34, Left=12, Height=32 };
        wrap.Paint += (s,e) => {
            e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
            using var p=new Pen(InputBrd,1);
            using var gp=RRect(new Rectangle(0,0,wrap.Width-1,31),6);
            e.Graphics.DrawPath(p,gp);
        };
        var lt=new TextBox { BackColor=Input, ForeColor=TextMut,
            Font=new Font("Courier New",10), BorderStyle=BorderStyle.None,
            Top=7, Left=10, Text="Target player UUID..." };
        lt.GotFocus  += (_,_) => { if(lt.ForeColor==TextMut){lt.Text="";lt.ForeColor=TextPri;} };
        lt.LostFocus += (_,_) => { if(string.IsNullOrEmpty(lt.Text)){lt.Text="Target player UUID...";lt.ForeColor=TextMut;} };
        lt.KeyDown   += (_,e) => { if(e.KeyCode==Keys.Return){e.SuppressKeyPress=true;onSend();} };
        txt=lt; wrap.Controls.Add(lt); card.Controls.Add(wrap);

        // button
        var lb2=new Button { Text=btnText, BackColor=btnColor, ForeColor=Color.White,
            Font=new Font("Segoe UI",9,FontStyle.Bold), FlatStyle=FlatStyle.Flat,
            Height=32, Top=34, Cursor=Cursors.Hand };
        lb2.FlatAppearance.BorderSize=0;
        lb2.FlatAppearance.MouseOverBackColor=ControlPaint.Light(btnColor,0.1f);
        lb2.FlatAppearance.MouseDownBackColor=ControlPaint.Dark(btnColor,0.1f);
        lb2.Click += (_,_) => onSend();
        btn=lb2; card.Controls.Add(lb2);

        card.Controls.Add(new Label {
            Text="Paste the target player UUID then press Enter or click the button",
            ForeColor=TextDim, Font=new Font("Segoe UI",7.5f), AutoSize=true,
            Top=80, Left=12, BackColor=Color.Transparent });

        return card;
    }

    // ── events ────────────────────────────────────────────────
    void GotAdd(CapturedRequest _)
    {
        _addBadge!.Text="  ADD token ready  ";
        _addBadge.ForeColor=Green; _addBadge.BackColor=Color.FromArgb(8,40,18);
        SetSt("ADD token captured", Green);
        WriteLog("ADD token captured — ready to send friend requests", LogLevel.Ok);
    }

    void GotRemove(CapturedRequest _)
    {
        _removeBadge!.Text="  REMOVE token ready  ";
        _removeBadge.ForeColor=Orange; _removeBadge.BackColor=Color.FromArgb(44,20,6);
        SetSt("REMOVE token captured", Orange);
        WriteLog("REMOVE token captured — ready to send remove requests", LogLevel.Ok);
    }

    async Task Go(bool isAdd)
    {
        var txt  = isAdd ? _txtAdd!      : _txtRemove!;
        var btn  = isAdd ? _btnAdd!      : _btnRemove!;
        var cap  = isAdd ? _engine.AddCapture : _engine.RemoveCapture;
        var path = isAdd ? PATH_ADD      : PATH_REMOVE;
        var lbl  = isAdd ? "ADD"         : "REMOVE";
        var okC  = isAdd ? Green         : Orange;

        var id = txt.Text.Trim();
        if (string.IsNullOrEmpty(id)||txt.ForeColor==TextMut)
        { WriteLog($"{lbl} — enter a player ID first", LogLevel.Err); return; }
        if (cap==null)
        { WriteLog($"{lbl} — no token yet, trigger a friend-{lbl.ToLower()} in DBD first", LogLevel.Err); return; }

        btn.Enabled=false;
        SetSt($"Sending {lbl}...", Purple);
        var (ok,status) = await _engine.SendRequest(cap, path, id);
        btn.Enabled=true;

        if (ok)
        {
            SetSt($"{lbl} sent", okC);
            WriteLog($"{lbl} sent successfully  ->  {id[..Math.Min(24,id.Length)]}", LogLevel.Ok);
        }
        else
        {
            SetSt($"{lbl} failed", RedClr);
            WriteLog($"{lbl} failed  ->  {status[..Math.Min(120,status.Length)]}", LogLevel.Err);
        }
    }

    void SetSt(string msg, Color c)
    {
        if (InvokeRequired){BeginInvoke(()=>SetSt(msg,c));return;}
        if (_lblStatus==null||_dotStatus==null) return;
        _lblStatus.Text=msg; _lblStatus.ForeColor=c;
        _dotStatus.BackColor=c; Circle(_dotStatus);
        LayoutBot(ClientSize.Width);
    }

    void WriteLog(string msg, LogLevel lvl)
    {
        if (InvokeRequired){BeginInvoke(()=>WriteLog(msg,lvl));return;}
        var c=lvl switch{LogLevel.Ok=>Green,LogLevel.Err=>RedClr,_=>TextMut};
        var ts=DateTime.Now.ToString("HH:mm:ss");
        _log!.SelectionStart=_log.TextLength; _log.SelectionColor=TextDim;
        _log.AppendText($"[{ts}]  ");
        _log.SelectionStart=_log.TextLength; _log.SelectionColor=c;
        _log.AppendText(msg+Environment.NewLine);
        _log.ScrollToCaret();
    }

    void TryInvoke(Action a){try{if(IsHandleCreated)BeginInvoke(a);}catch{}}

    static void Circle(Panel p)
    {var gp=new GraphicsPath();gp.AddEllipse(0,0,p.Width,p.Height);p.Region=new Region(gp);}

    static GraphicsPath RRect(Rectangle r,int rad)
    {
        var p=new GraphicsPath();
        p.AddArc(r.X,r.Y,rad*2,rad*2,180,90);
        p.AddArc(r.Right-rad*2,r.Y,rad*2,rad*2,270,90);
        p.AddArc(r.Right-rad*2,r.Bottom-rad*2,rad*2,rad*2,0,90);
        p.AddArc(r.X,r.Bottom-rad*2,rad*2,rad*2,90,90);
        p.CloseFigure();return p;
    }
}

class DoubleBufferedPanel:Panel{public DoubleBufferedPanel(){DoubleBuffered=true;}}

static class Win
{
    [System.Runtime.InteropServices.DllImport("wininet.dll")]
    public static extern bool InternetSetOption(IntPtr h,int opt,IntPtr buf,int len);
}
